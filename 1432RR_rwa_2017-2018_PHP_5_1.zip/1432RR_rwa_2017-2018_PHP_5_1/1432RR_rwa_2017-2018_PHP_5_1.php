<?php
echo "Ispis brojeva od 1 do 10: <br/>";
for($i=1; $i<=10; $i++)
echo "$i <br/>";
?>