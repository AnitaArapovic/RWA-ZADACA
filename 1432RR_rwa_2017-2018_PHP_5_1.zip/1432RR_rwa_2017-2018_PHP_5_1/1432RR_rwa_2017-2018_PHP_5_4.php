<?php
function aritmeticka_sredina($a, $b){
$rez=($a+$b)/2;
echo "Aritmeticka sredina brojeva $a i $b je $rez.";
}

aritmeticka_sredina(8,15);
?>
