<?php
$kvadrat;
echo "Ispis parnih brojeva od 1 do 20 te njihovih kvadrata: <br/>";
for($i=1; $i<=20; $i++)
if($i%2==0){
$kvadrat=$i*$i;
echo "$i<sup>2</sup> =  $kvadrat<br/>";
}
?>