<?php
function prost($a)
{
$pom=0;
for($i=2; $i<=$a/2; $i++)
{
	if($a%$i==0)
		$pom=1;	
}
if($pom==0)
return true;
}

$i=1;
echo "Prosti brojevi manji od 100: <br/>";
while($i<100)
{
	if(prost($i)==true){
		echo "$i  ";
	}
$i++;
}
?>